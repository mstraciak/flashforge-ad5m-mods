var searchData=
[
  ['fillrect',['fillRect',['../class_nano_canvas_ops.html#a75cec98f3392b850a680efc5a0f7509d',1,'NanoCanvasOps::fillRect(lcdint_t x1, lcdint_t y1, lcdint_t x2, lcdint_t y2)'],['../class_nano_canvas_ops.html#a3db1c1ee61605a3ed9e7a9b67f988018',1,'NanoCanvasOps::fillRect(const NanoRect &amp;rect)'],['../class_nano_canvas.html#a3f987bce72b865a483c4a65922b7cc45',1,'NanoCanvas::fillRect()']]],
  ['fliph',['flipH',['../class_nano_canvas.html#a3f069cfd24e79cb420f2fe2af5e51857',1,'NanoCanvas']]]
];
