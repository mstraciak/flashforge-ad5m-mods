var searchData=
[
  ['direct_20draw_3a_2016_2dbit_20api_20functions_20only_20for_20color_20displays',['DIRECT DRAW: 16-bit API functions only for color displays',['../group___l_c_d__16_b_i_t___g_r_a_p_h_i_c_s.html',1,'']]],
  ['direct_20draw_3a_201_2dbit_20graphic_20functions_20for_20ssd1306_20compatible_20mode_2e',['DIRECT DRAW: 1-bit graphic functions for ssd1306 compatible mode.',['../group___l_c_d__1_b_i_t___g_r_a_p_h_i_c_s.html',1,'']]],
  ['direct_20draw_3a_208_2dbit_20api_20functions_20only_20for_20color_20displays',['DIRECT DRAW: 8-bit API functions only for color displays',['../group___l_c_d__8_b_i_t___g_r_a_p_h_i_c_s.html',1,'']]],
  ['direct_20draw_3a_20generic_20api_20functions_2c_20common_20for_20all_20displays_20and_20all_20display_20modes_2e',['DIRECT DRAW: Generic API functions, common for all displays and all display modes.',['../group___l_c_d___g_e_n_e_r_i_c___a_p_i.html',1,'']]]
];
