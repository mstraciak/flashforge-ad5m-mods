var searchData=
[
  ['il9163_2fst7735_3a_20il9163_2fst7735_20control_20functions',['IL9163/ST7735: il9163/st7735 control functions',['../group___i_l9163___s_t7734___a_p_i.html',1,'']]],
  ['ili9341_3a_20ili9341_20control_20functions',['ili9341: ili9341 control functions',['../group__ili9341___a_p_i.html',1,'']]],
  ['i2c_2fspi_3a_20physical_20interface_20functions',['I2C/SPI: physical interface functions',['../group___l_c_d___h_w___i_n_t_e_r_f_a_c_e___a_p_i.html',1,'']]]
];
