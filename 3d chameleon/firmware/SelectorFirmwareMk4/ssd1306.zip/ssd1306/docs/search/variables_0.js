var searchData=
[
  ['ascii_5foffset',['ascii_offset',['../struct_s_font_header_record.html#a2b7b768b98e4da20a932b32d7980dde1',1,'SFontHeaderRecord']]]
];
